package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Message;

public class ChatDAO {
	//DB接続情報
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/chatdb";
	private static String USER = "root";
	private static String PASS = "root123";
	
	//PreparedStatementをりよSQL文
	private static final String INSERT_MESSAGE_SQL = "INSERT INTO messages (sender, content, timestamp) VALUES (?, ?, ?)";
	private static final String SELECT_ALL_MESSAGES_SQL = "SELECT * FROM messages ORDER BY timestamp";

	public static Connection getConnection() {

		try {

			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public void addMessage(Message message) throws SQLException {
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_MESSAGE_SQL)) {
			
			//引数のmessageオブジェクトを利用して各インスタンス変数をSQL文に反映
			preparedStatement.setString(1, message.getSender());
			preparedStatement.setString(2, message.getContent());
			preparedStatement.setString(3, message.getTimestamp());
			
			//SQL文を発行
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<Message> getMessages() {
		
		//messageクラスのListを作成
		List<Message> messages = new ArrayList<>();
		
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_MESSAGES_SQL);
				ResultSet rs = preparedStatement.executeQuery()) {
			
			//DBから戻ってきた結果セットから各カラム値を取得し、messageオブジェクトに格納
			while (rs.next()) {
				int id = rs.getInt("id");
				String sender = rs.getString("sender");
				String content = rs.getString("content");
				String timestamp = rs.getString("timestamp");
				messages.add(new Message(sender, content, timestamp));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return messages;
	}
}
