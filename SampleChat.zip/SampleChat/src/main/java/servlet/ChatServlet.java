package servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Message;
import service.ChatService;

@WebServlet("/chat")
public class ChatServlet extends HttpServlet {
    private ChatService chatService = new ChatService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	
    	//DBに登録されているメッセージを取得し、リクエストスコープに登録
        req.setAttribute("messages", chatService.getMessages());
        
        //chat.jspにフォワード処理
        req.getRequestDispatcher("/view/chat.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	
    	//送信者、本文のリクエストパラメータを取得
        String sender = req.getParameter("sender");
        String content = req.getParameter("content");
        
        //現在の日時を取得
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        
        //送信者、本文、日付を引数にmessageオブジェクトを生成
        Message message = new Message(sender, content, timestamp);
        
        //messageオブジェクト情報をDBに登録
        chatService.addMessage(message);
        
        //ChatServletにリダイレクトし、chat.jspに遷移
        resp.sendRedirect("chat");
    }
}
