package service;

import java.sql.SQLException;
import java.util.List;

import dao.ChatDAO;
import model.Message;

public class ChatService {
    private ChatDAO chatDAO = new ChatDAO();
    
    //addMessageの実行用メソッド
    public void addMessage(Message message) {
        try {
            chatDAO.addMessage(message);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //getMessageの実行用メソッド
    public List<Message> getMessages() {
        return chatDAO.getMessages();
    }
}
